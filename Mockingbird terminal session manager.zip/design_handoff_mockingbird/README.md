# Handoff: Mockingbird UI — v1 grid + v2 backlog surfaces

## Overview

Mockingbird is a macOS (Electron) manager for a grid of live Claude CLI terminal
sessions. This package covers a visual cleanup of the existing v1 sessions grid
plus first designs for seven backlog surfaces: ADO ticket sidebar, command
palette / keyboard layer, menu-bar + Dock glanceability, worktree hygiene,
per-pane session context, cross-session transcript search, and the broadcast /
CLAUDE.md control room.

## About the Design Files

The files in this bundle are **design references created in HTML** — prototypes
showing intended look and behavior, not production code to copy. `Mockingbird.dc.html`
is a single streaming HTML document containing eight labelled option cards laid
out on a pannable canvas; it is a *specification surface*, not an app.

The task is to **recreate these designs inside Mockingbird's existing renderer**
(React/Electron), using its established component patterns, state, and styling
approach. Do not port the inline styles verbatim — lift the token values below
into whatever the app already uses (CSS variables, styled-components, Tailwind
config, etc.). Nothing here should introduce a new styling system.

Open `Mockingbird.dc.html` in a browser to view it (`support.js` must sit
beside it). Each design is tagged with a stable id — `1a` through `1h` — shown
as a badge above it; those ids are the vocabulary for follow-up discussion.

## Fidelity

**High-fidelity.** Final colors, typography, spacing, and copy. Recreate the UI
closely. Two qualifications:

1. The design was produced **without access to the Mockingbird codebase** (the
   local folder could not be read). Component names, existing layout primitives,
   and current DOM structure are unknown. Where this design conflicts with an
   existing pattern in the app, the existing pattern usually wins — the intent
   here is the visual system and the information hierarchy, not the markup.
2. Terminal pane content is **illustrative**. Two panes show realistic CLI
   output; the rest show abstracted grey bars standing in for streamed text.
   Real panes render actual terminal output (xterm.js or equivalent).

## Design Tokens

### Color

| Token | Hex | Use |
|---|---|---|
| `bg/app` | `#1a1917` | app background, gutters between panes |
| `bg/chrome` | `#1f1e1b` | top bar, status bar, panel footers |
| `bg/sidebar` | `#1d1c19` | left sidebar, search result group headers |
| `bg/pane` | `#201f1c` | terminal pane body, cards |
| `bg/pane-header` | `#242320` | pane title bar, popover/dialog surfaces |
| `bg/pane-dead` | `#1d1c1a` | dead-session pane, de-emphasised rows |
| `bg/pane-waiting` | `#2a2318` | pane header of a session waiting on input |
| `text/primary` | `#e8e4dc` | session names, headings, live terminal text |
| `text/primary-warm` | `#f0e6d4` | primary text inside amber (waiting) contexts |
| `text/secondary` | `#c9c3b8` | inactive session names, body copy, filenames |
| `text/tertiary` | `#9a938a` | metadata, section labels, timestamps |
| `text/quaternary` | `#7d766b` | keyboard hints, rail labels, byte counts |
| `accent/waiting` | `#e0a34a` | **reserved exclusively for "a session needs you"** + primary buttons |
| `accent/waiting-text` | `#c9a877` | text on amber-tinted surfaces |
| `accent/waiting-text-dim` | `#a3906d` | metadata on amber-tinted surfaces |
| `status/working` | `#4fb3a5` | working dot, passing tests, healthy git state |
| `status/working-text` | `#7fb8ae` | teal text on dark (ticket chips, PR state) |
| `status/idle` | `#8d877c` | idle dot |
| `status/dead` | `#cf6a5a` | dead dot, dirty worktree, destructive action |
| `line/strong` | `rgba(255,255,255,.09)` | pane borders, card borders |
| `line/medium` | `rgba(255,255,255,.07)` | chrome dividers |
| `line/soft` | `rgba(255,255,255,.05–.06)` | in-panel row dividers |
| `fill/subtle` | `rgba(255,255,255,.05)` | branch chips, filter field, key caps |
| `fill/selected` | `rgba(255,255,255,.06)` | selected sidebar row |
| `fill/waiting` | `rgba(224,163,74,.12–.13)` | waiting banners, selected palette row |
| `fill/waiting-glow` | `rgba(224,163,74,.13)` | 3px outer ring on waiting panes |

**The amber rule is the core of the system: `#e0a34a` means "blocked on you"
and nothing else.** It is also used as the primary-button fill (with `#1a1917`
text), which is acceptable because those buttons are the resolution of a
waiting state. Never use amber for branding, focus rings, links, or emphasis.

### Typography

Two families only.

- **UI:** `'Helvetica Neue', Helvetica, Arial, sans-serif` — anything the user clicked.
- **Machine:** `'JetBrains Mono', ui-monospace, Menlo, monospace` — anything the machine produced: terminal output, branch names, counts, costs, timestamps, keyboard hints, file paths.

| Role | Spec |
|---|---|
| App title | 600 12.5px, `letter-spacing:.2px` |
| Panel/dialog title | 600 11.5–13px |
| Pane title (standard) | 500 11.5px UI |
| Pane title (instrumented) | 500 12.5px UI |
| Session row (selected) | 500 11px UI |
| Session row (default) | 400 11px UI |
| Section label | 500 9px UI, `letter-spacing:.9–1px`, uppercase |
| Rail label (CONTEXT/COST/…) | 400 8.5px UI, `letter-spacing:.6px`, uppercase |
| Button label | 500 10–10.5px UI (600 on primary) |
| Terminal body | 400 10.5px/1.6 mono (11px/1.65 in instrumented pane) |
| Pane header meta | 400 9.5px mono |
| Keyboard hint | 400 9–9.5px mono |
| Status bar | 400 10px mono |
| Editor body (CLAUDE.md) | 400 11px/1.75 mono |

### Spacing, radius, shadow

- Grid gutter and pane padding: `8px`. Pane header padding: `7px 9px`.
- Chrome heights: top bar `40px`, status bar `28px`, sidebar `232px` wide.
- Radius: pane/card `6px`, control/chip/button `5px`, small chip `3–4px`,
  popover `8px`, dialog `9px`, palette `10px`, Dock icon `12px`.
- Shadows: popover `0 14px 34px rgba(0,0,0,.5)`, dialog `0 20px 44px rgba(0,0,0,.5)`,
  command palette `0 24px 60px rgba(0,0,0,.6)`.
- Status dot: `6px` circle in headers and lists, `5px` inline in status bar and
  banners, `7px` in the instrumented pane header.

---

## Screens / Views

### 1a — Sessions grid (the main window)

**Purpose:** the app's home. See every live session at once, spot the ones
blocked on you, jump into one.

**Layout:** vertical stack — top bar (40px, fixed) / body (flex:1) / status bar
(28px, fixed). Body is sidebar (232px, fixed) + grid (flex:1). Grid is
`display:grid; grid-template-columns:repeat(N,1fr); grid-template-rows:repeat(M,1fr); gap:8px; padding:8px`
where N is the column control's value (1–4) and rows follow from session count.
Panes are equal-size cells; every pane has `min-height:0` and `overflow:hidden`
so terminal output clips rather than stretching the row.

**Top bar** (`#1f1e1b`, bottom border `line/medium`), left to right:
- Brand: 14px amber rounded square + "Mockingbird" (600 12.5px) + version (`9.5px` mono, tertiary).
- Column segmented control: 4 cells `1 2 3 4` in a `rgba(255,255,255,.05)` track, `2px` padding, `5px` radius; selected cell is `#c9c3b8` fill with `#1a1917` text, `3px` radius. Label "cols" (10px UI, tertiary) to its right.
- 1px × 18px divider, then two outline buttons: "Enlarge 2×2", "Zoom 100%" (500 10.5px, `1px solid rgba(255,255,255,.1)`, `5px 9px`, radius 5).
- Right group: transcript search field (196px wide, outline, placeholder "Search all transcripts", right-aligned `⌘⇧F` hint), "Broadcast" and "CLAUDE.md" outline buttons, then the primary "New session" button (amber fill, `#1a1917` text, 600 10.5px, with a 60%-opacity `⌘N` hint inside).

**Sidebar** (`#1d1c19`, right border):
- Filter field: `6px 8px`, `fill/subtle`, `1px solid rgba(255,255,255,.07)`, radius 5, 9px circle glyph + "Filter sessions".
- Groups by ticket. Group header = uppercase 9px label (`EPS-5038 · AUTH RETRY`) followed by a 1px hairline filling the row.
- Session row: `6px 8px`, radius 5, `gap:7px` — status dot, name (ellipsised), then the pane index in 9px mono, quaternary. Selected row: `fill/selected` + 500 weight + primary text color. Rows are drag handles for reordering; names are inline-editable on double-click.
- Footer pinned to bottom (`margin-top:auto`, top border): "WorkTracker" label + schedule note, then two equal outline buttons "Morning brief" / "4pm wrap-up".

**Terminal pane — default state.** `#201f1c`, `1px solid rgba(255,255,255,.09)`, radius 6, `overflow:hidden`, column flex.
- Header (`#242320`, `7px 9px`, `gap:7px`, bottom border `rgba(255,255,255,.06)`): status dot → name (500 11.5px UI) → branch chip (9.5px mono, `fill/subtle`, `3px 5px`, radius 3) → `margin-left:auto` → meta string (9.5px mono, tertiary) in the fixed order **git · tokens · cost · elapsed**, e.g. `↑3 ✓clean · 41.2k · $1.14 · 18m`.
- Body: `padding:9px`, terminal text at 10.5px/1.6 mono. Live output is `text/tertiary`; the user's own prompt line and filenames are `text/secondary`; success lines are `status/working`.
- Optional last line: a status footer (`9.5px` mono, quaternary) such as `idle 22m · ready for broadcast`.

**Terminal pane — waiting state** (the design's most important element):
- Border becomes `1px solid #e0a34a` **plus** `box-shadow: 0 0 0 3px rgba(224,163,74,.13)`.
- Header background → `#2a2318`; header border → `rgba(224,163,74,.2)`; name → `#f0e6d4`; branch chip → `rgba(224,163,74,.12)` / `#c9a877`; meta → `#a3906d`.
- Body ends with a waiting banner: `5px 7px`, radius 4, `rgba(224,163,74,.13)`, amber 5px dot + reason text (500 10px UI, amber) + right-aligned pane shortcut. Reason text is specific — "waiting for you · 3m 40s", "permission: write outside worktree" — never a generic "waiting".

**Terminal pane — dead state:** `#1d1c1a`, `1px dashed rgba(207,106,90,.35)`, red dot, muted title. Body is centred: "history preserved · 87 turns" (10.5px mono) plus two buttons, "Resume" (stronger outline) and "Close & clean up" (weaker outline).

**Assistant pane:** `1px solid rgba(79,179,165,.28)` border, header background `#202726`, teal chip for the instruction file name (`morning-brief`), meta shows the schedule (`auto 09:00`).

**Status bar** (`#1f1e1b`, top border, `gap:14px`, 10px mono): four status counts each as dot + label (the waiting count is amber-colored, the rest tertiary) · 1px divider · worktree health (`3 worktrees dirty · 1 stale`) · `margin-left:auto` · session totals (`$5.77 · 215k tokens`) · `⌘K commands` hint.

### 1b — Pane density tiers

Three variants of the same pane, switched by column count. Implement as one
component with a `density` prop derived from column count (or an override).

- **Minimal** (4 cols, ~96px tall): dot + name + right-aligned pane shortcut only. No branch, no meta. Header padding drops to `6px 8px`, name to 11px.
- **Standard** (3 cols, ~132px): the default described in 1a.
- **Instrumented** (1–2 cols): header padding `8px 10px`, dot 7px, name 12.5px, branch chip **and** a teal ticket chip (`EPS-5038 · Active`), shortcut right-aligned. Below the header, a **context rail**: a 5-cell flex row on `#1e1d1a` with 1px dividers, each cell `7px 10px` and stacking an 8.5px uppercase label over a 10.5px mono value — `CONTEXT 41.2k / 200k`, `COST $1.14`, `ELAPSED 18m 04s`, `GIT ↑3 ↓0 clean`, `PR #218 open` (PR value in teal). Body text steps up to 11px/1.65.

### 1c — Command palette (⌘K) and keyboard layer

**Purpose:** make 10+ sessions navigable without the mouse.

Modal over a dimmed, 1.5px-blurred grid at 40% opacity plus a `rgba(12,11,10,.55)`
scrim. Palette is 520px wide, centred horizontally, 44px from the top,
`#242320`, `1px solid rgba(255,255,255,.14)`, radius 10.

- **Input row:** `13px 14px`, amber `›` prompt glyph, query at 14px UI, a 1.5px × 15px amber caret, right-aligned "esc to close".
- **Results:** grouped, each group preceded by a 9px uppercase label (`ACTIONS`, `JUMP TO SESSION`). Action row: `8px 14px`, label 12.5px UI, right-aligned shortcut in 9.5px mono. Session row adds a leading status dot and a state phrase ("waiting 3m", "permission prompt") between name and shortcut. **Selected row:** `rgba(224,163,74,.12)` fill + `2px solid #e0a34a` left border + `#f0e6d4` text.
- 1px divider between groups, `margin:6px 0`.
- **Footer:** `9px 14px`, `#1f1e1b`, top border, 9.5px mono hints: `↑↓ move`, `⏎ run`, `⇥ scope to selection`, right-aligned `⌘J note`.

**Full shortcut map** (also shown as a chip row in the design): `⌘N` new session ·
`⌘1–9` jump to pane · `⌘J` note · `⌘K` palette · `⌘⇧F` search transcripts ·
`⌥⇥` next waiting session · `⌘E` enlarge 2×2 · `⌘⌃1–4` column count ·
`⌘⇧B` broadcast to all idle · `⌥⇧B` broadcast to selection · `⌘⇧R` broadcast
"re-read CLAUDE.md" · `⌘⏎` (in search) resume dead session at that turn.

Shortcut hints appear **inline wherever the action lives** — in the pane
waiting banner, the sidebar rows, the top bar buttons — so the mapping is
learned in place rather than from a cheat sheet.

### 1d — ADO ticket sidebar (v2)

**Purpose:** replace the manual ticket text field. Work items are the objects
you create sessions from, and the place draft comments accumulate.

400px panel. Header: "Assigned to me" (600 11.5px) + `Epsilon · 6` + right-aligned
`synced 2m ago` (9px mono). Filter row of four pills: `Active / Review / New / All`,
`5px 8px`, radius 4; selected is `#c9c3b8` fill with dark text.

**Work item card:** `#201f1c`, `1px solid rgba(255,255,255,.09)`, radius 6,
`padding:10px`, `gap:7px`:
- Meta row: item id (500 9.5px mono) + type chip (`Task` / `User Story` / `Bug`, 8.5px UI on `fill/subtle`) + right-aligned ADO state (9px mono; Active in teal, New in tertiary).
- Title: 500 12px/1.4 UI, primary.
- Link row: session count with a status dot + worktree name, or a red worktree warning (`wt dirty · 7 ahead`).
- Items with no session yet get a "Start session" outline button plus a 9.5px mono note naming the worktree it will create (`creates worktree 5101-filter-groups`).

**Active card with a queued comment** (the amber-bordered one): `1px solid rgba(224,163,74,.4)`
on `#221f1a`, item id in amber. It contains a **draft comment block** —
`rgba(255,255,255,.04)`, `2px solid #4fb3a5` left border, `7px 8px`, radius 4,
with a 9px teal `DRAFT COMMENT` label over the body at 10px/1.5 mono — then two
buttons: primary amber "Post to ADO" and outline "Edit in pending-comments.md".

Non-active items render at `opacity:.72` on `#1d1c1a`. Footer: `1 comment queued`
left, `pending-comments.md` right.

### 1e — Worktree hygiene

Two pieces.

**(a) Worktrees drawer.** Header: "Worktrees" + `3 dirty` (red) + `· 1 stale · 1.9 GB`
(tertiary) + right-aligned "Prune merged" outline button. Rows are a fixed-column
table at `9px 12px` with 1px dividers: name (10.5px mono, 150px) · state (10px
mono, 110px — `clean · ↑3` teal, `dirty · 12 files` red, `merged` tertiary) ·
detail (flex:1 — `active now · PR #218 open`, `↑7 ↓2 · no PR`, `branch deleted on remote`,
`safe to delete`) · contextual action button · size (9.5px mono, quaternary).
Rows needing attention get a `rgba(207,106,90,.05)` background tint.

**(b) Close-session dialog.** 420px, `#242320`, `1px solid rgba(255,255,255,.14)`,
radius 9. Title "Close billing-export?" (600 13px). Body sentence states the exact
consequence, with the worktree name in mono/secondary. Three radio options, each
a `9px 10px` bordered row stacking a 500 11.5px label over a 10px/1.4 mono
consequence line:
1. *Keep worktree, close pane* — "nothing is lost; shows under Worktrees" — **selected by default**, `1px solid rgba(224,163,74,.4)` + `rgba(224,163,74,.09)` fill, radio is a 12px circle with a 4px amber ring.
2. *Push branch, then remove worktree* — "commits WIP as 4912-csv-wip".
3. *Discard everything and delete* — label in `status/dead`, "frees 704 MB · not recoverable".

Footer: `⏎ to confirm` hint left, "Cancel" outline + "Close session" amber primary right.
The safe option is always preselected; the destructive one is never the default.

### 1f — Cross-session transcript search

660px panel, 470px tall. Search row: amber `/` glyph, query at 13.5px mono,
amber caret, right-aligned result summary (`14 hits · 5 sessions · 31 days`).
Filter row of pills: `All sessions` (selected) / `Live only` / `EPS-5038` /
`my messages` / `tool calls`.

Results grouped **by session**, not by recency. Group header sits on `#1d1c19`
with a top border: status dot + session name (500 11px UI) + `branch · N hits`
(9.5px mono). Result row: `8px 14px`, a 9px mono attribution line
(`turn 12 · you · today 10:04`) over the excerpt at 11px/1.6 mono. Query matches
are highlighted `rgba(224,163,74,.14)` with `#e8e4dc` text; in the **selected**
row the highlight strengthens to `rgba(224,163,74,.22)` with `#f0e6d4`, the row
gets an amber left border and `rgba(224,163,74,.08)` fill, and a right-aligned
`⏎ open pane` hint appears in the attribution line.

Dead and imported sessions are searchable and labelled as such
(`dead · imported from cmux · 4 hits`). Footer hints: `↑↓ results`,
`⌘⏎ resume dead session at this turn`, right-aligned `⌘J save as note`.

### 1g — Broadcast + CLAUDE.md control room

760px × 480px, split into an editor (flex:1) and a broadcast rail (320px fixed),
divided by a 1px border.

**Editor pane.** Header: "CLAUDE.md" + file path (9.5px mono, tertiary) +
right-aligned `unsaved` in amber. Body is a plain mono editor at 11px/1.75;
headings in `text/secondary`, body in tertiary. **Changed lines** are marked with
a `2px solid #e0a34a` left border and `rgba(224,163,74,.1)` fill bleeding to the
pane edge (negative margin equal to the padding). Footer: `+2 lines` left, then
"Save" outline and the amber primary **"Save & re-read in 4"** — the count is
the number of sessions that will be told to re-read.

**Broadcast rail.** Header "Broadcast" + `⌘⇧B`. Composer: a bordered textarea
(`#201f1c`, radius 6, 11px/1.6 mono) with an amber caret; below it three target
pills (`All idle (5)` selected / `Selected (3)` / `By ticket`); then a full-width
amber primary "Queue for 9 sessions".

**Delivery list** (the reason this screen exists): a `DELIVERY` section label
over one row per session — status dot + name (10.5px mono) + right-aligned
delivery state. States: `delivered 10:41` (teal), `queued · busy` (amber),
`queued · prompt open` (amber), `skipped · dead` (tertiary). This makes the
"delivered only when idle" behavior visible instead of implicit.

### 1h — Menu bar and Dock

**Menu-bar item.** Three states in one 26px pill: idle = grey 11px rounded
square, no count; working = teal square + count in 10.5px mono secondary;
waiting = amber square + amber 600 count on a `rgba(224,163,74,.16)` rounded
background. Only the waiting state gets a background.

**Dropdown.** 280px, `#282522`, `1px solid rgba(255,255,255,.12)`, radius 8.
Waiting sessions come first under an amber `WAITING FOR YOU · 2` label, each row
tinted `rgba(224,163,74,.1)` with the wait duration right-aligned; clicking one
raises the app and focuses that pane. A divider, then collapsed summary rows
(`4 working`, `2 idle · 1 dead`), another divider, then actions (`New session ⌘N`,
`Run 4pm wrap-up`).

**Dock icon.** 52px, radius 12, `#242320` tile with a 20px amber mark, plus a
badge at `top:-6px; right:-6px`: min-width 20px, 20px tall, radius 10,
`#cf6a5a` fill, white 700 11px numeral, `1.5px solid` the surrounding background.
**The badge counts sessions blocked on you only — never working sessions.**
No badge when nothing is waiting.

---

## Interactions & Behavior

- **Status is hook-driven**, four states: working / waiting / idle / dead. The visual vocabulary is one 6px dot everywhere. Escalation is deliberate: dot only → dot + waiting banner in the pane body → full amber border + 3px glow. A session that merely finished a step does *not* escalate; only blocked-on-input does.
- **Waiting pulse:** the amber dot pulses (opacity 1 → .45 → 1, ~1.6s, ease-in-out). No other element animates on the grid. Respect `prefers-reduced-motion` by holding the dot at full opacity.
- **Panes are drag-reorderable**; drop targets are the grid cells. Double-click a pane header name or a sidebar row name to rename inline.
- **⌘E / "Enlarge 2×2"** promotes the focused pane to span two columns and two rows in place; the remaining panes reflow around it.
- **Column control** sets grid columns 1–4 and switches pane density (1b) at the same time.
- **⌥⇥ cycles waiting sessions** oldest-wait first — the primary keyboard motion for a busy grid.
- **Broadcast delivery** is queued per session and flushed when that session reaches idle; the delivery list (1g) updates live. Dead sessions are skipped, not queued.
- **"Save & re-read"** writes CLAUDE.md then broadcasts a re-read instruction to every session rooted in that repo; no restart.
- **Close-session** always opens the dialog (1e) when the worktree is dirty or has unpushed commits; when it is clean and merged, close silently and offer an undo toast instead.
- **Search** (⌘⇧F) covers live, idle, and dead sessions including imported CLI history. `⏎` opens the pane scrolled to that turn; `⌘⏎` resumes a dead session from that turn.
- **Notifications:** native notification on a session entering *waiting*, coalesced — no more than one per session per 30s, and suppressed while that pane is focused.
- **Persistence:** grid order, enlarged pane, column count, sidebar collapse state, group collapse state, and zoom all persist across restarts, keyed per workspace.

## State Management

Per session: `id`, `name`, `repoPath`, `worktreePath`, `branch`, `ticketId`,
`status` (working|waiting|idle|dead), `waitingReason`, `waitingSince`,
`startedAt`, `tokensUsed`, `tokenBudget`, `costUsd`, `git` ({ahead, behind, dirtyFiles, staleDays, merged, prNumber, prState}), `paneIndex`, `isEnlarged`, `pendingBroadcasts[]`.

App-level: `columns` (1–4), `zoom`, `sidebarCollapsed`, `filterQuery`,
`selectedSessionIds[]`, `paletteOpen` + `paletteQuery`, `searchOpen` +
`searchQuery` + `searchFilters`, `broadcastDraft` + `broadcastTargets`,
`claudeMdDraft` + `claudeMdDirty`, `worktrees[]`, `adoWorkItems[]` +
`adoLastSyncedAt` + `pendingComments[]`.

Data sources: session status from the existing hook mechanism; token/cost from
the CLI's own usage reporting; git state from a periodic `git status`/`rev-list`
per worktree (poll ~10s, or watch); PR state from the git host API; work items
from the ADO REST API for the current user, refreshed on window focus and on a
few-minute timer.

## Assets

None. Every glyph in the design is a plain CSS shape (circles, rounded squares,
1px rules) or a Unicode character (`↑ ↓ ✓ ⚠ › / ⏎ ⇥ ⌘ ⌥ ⌃ ⇧ •`). If the app
already has an icon set, use it — but keep status as a dot, not a glyph, so the
four states stay distinguishable at 6px.

Fonts: JetBrains Mono (Google Fonts, weights 400/500/700) and Helvetica Neue
(system). Bundle JetBrains Mono locally in the Electron app rather than loading
it from the network.

## Files

- `Mockingbird.dc.html` — all eight designs (`1a`–`1h`) on one canvas. Open in a browser; pan/scroll to move between cards. This is the source of truth for every measurement above.
- `support.js` — runtime required to render the HTML file. Not part of the design.

## Open questions for the team

1. Does the existing renderer have a component/token layer these values should map onto? The design assumes none and states raw hex.
2. Instrumented pane rail (1b) — poll cost/git per pane, or centrally per worktree?
3. ADO draft comments — is `pending-comments.md` per repo or global?
4. Does the transcript index need to be built at import time for cmux history, or can it be searched lazily?
